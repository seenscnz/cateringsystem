import java.io.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

// ...

private static final String SIGNUP_DATA_FILE = "signup_data.txt";
private static final Map<String, String> signupData = new HashMap<>();



private void loadSignupData() {
    try (BufferedReader reader = new BufferedReader(new FileReader(SIGNUP_DATA_FILE))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 2) {
                String username = parts[0];
                String password = parts[1];
                signupData.put(username, password);
            }
        }
    } catch (IOException e) {
        // Handle file read error, if necessary
    }
}
private void saveSignupData() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(SIGNUP_DATA_FILE))) {
        for (Map.Entry<String, String> entry : signupData.entrySet()) {
            String username = entry.getKey();
            String password = entry.getValue();
            writer.write(username + "," + password);
            writer.newLine();
        }
    } catch (IOException e) {
        // Handle file write error, if necessary
    }
}

// ...

public static void main(String args[]) {
    // Load the signup data from the file
    loadSignupData();

    // Create and display the login frame
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new LoginFrame().setVisible(true);
        }
    });
}
---------------------
import JFrames.HttpHelper;
import javax.swing.JOptionPane;

// ...

private void btn_submitLoginMouseClicked(java.awt.event.MouseEvent evt) {
    String username = text_username.getText(); // Get the username entered by the user
    String password = new String(text_pass.getPassword()); // Get the password entered by the user

    // Perform login logic
    if (performLogin(username, password)) {
        // Successful login
        JOptionPane.showMessageDialog(this, "Login successful!");
        openHomePage();
    } else {
        // Failed login
        JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Failed", JOptionPane.ERROR_MESSAGE);
    }
}

private boolean performLogin(String username, String password) {
    // Here you can implement your own login logic by making a request to your API.
    // For demonstration purposes, let's assume the API endpoint for login is '/api/login' and it expects username and password as query parameters.

    // Build the API URL with the username and password query parameters
    String apiUrl = "https://your-api-url.com/api/login?username=" + username + "&password=" + password;

    try {
        // Send an HTTP GET request to the API
        HttpHelper httpHelper = new HttpHelper();
        String response = httpHelper.sendGetRequest(apiUrl);

        // Parse the response and check if the login was successful
        // The response can be in JSON or any other format depending on your API
        // You need to adapt the code to parse the response based on your API's response format
        if (response.equals("success")) {
            return true; // Login successful
        }
    } catch (Exception e) {
        e.printStackTrace();
        // Handle any exception that occurred during the request or response processing
    }

    return false; // Login failed
}
