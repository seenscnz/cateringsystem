import javax.xml.bind.DatatypeConverter;

public class hello {

    public static void main(String[] args) {
        String username = "huzaif";
        String password = "huzaif";
        String combinedString = username + ":" + password;

        String encodedCredentials = DatatypeConverter.printBase64Binary(combinedString.getBytes());

        System.out.println("Encoded credentials: " + encodedCredentials);
    }

    // Other methods and code within your class
}
